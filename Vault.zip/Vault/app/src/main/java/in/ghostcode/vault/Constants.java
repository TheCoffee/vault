package in.ghostcode.vault;

/**
 * Created by ghost on 9/18/16.
 */
public class Constants {
    public static final String TYPE = "type";
    public static final String NEW_NOTE = "new note";
    public static final String EDIT_NOTE = "edit note";
    public static final String NOTE = "NOTE";
}
